const router = require("express").Router();
const auth = require("../middleware/auth");
const validate = require("../middleware/validate");
const {
  createTask,
  listTasks,
  getTask,
  updateTask,
  deleteTask,
} = require("../controllers/taskController");
const {
  createTaskValidator,
  updateTaskValidator,
  taskIdValidator,
  listTasksValidator,
} = require("../validators/taskValidators");

router.use(auth);

router.get("/", validate(listTasksValidator), listTasks);
router.post("/", validate(createTaskValidator), createTask);
router.get("/:id", validate(taskIdValidator), getTask);
router.put("/:id", validate(updateTaskValidator), updateTask);
router.delete("/:id", validate(taskIdValidator), deleteTask);

module.exports = router;
