const router = require("express").Router();
const { register, login } = require("../controllers/authController");
const validate = require("../middleware/validate");
const { registerValidator, loginValidator } = require("../validators/authValidators");

router.post("/register", validate(registerValidator), register);
router.post("/login", validate(loginValidator), login);

module.exports = router;
