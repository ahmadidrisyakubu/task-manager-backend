const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const Task = require("../models/Task");

exports.createTask = asyncHandler(async (req, res) => {
  const { title, description = "", status = "pending", dueDate = null } = req.body;

  const task = await Task.create({
    user: req.user.id,
    title,
    description,
    status,
    dueDate: dueDate ? new Date(dueDate) : null,
  });

  res.status(201).json({ success: true, task });
});

exports.listTasks = asyncHandler(async (req, res) => {
  const page = parseInt(req.query.page || "1", 10);
  const limit = Math.min(parseInt(req.query.limit || "10", 10), 100);
  const status = req.query.status;

  const filter = { user: req.user.id };
  if (status) filter.status = status;

  const [tasks, total] = await Promise.all([
    Task.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit),
    Task.countDocuments(filter),
  ]);

  res.json({
    success: true,
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
    tasks,
  });
});

exports.getTask = asyncHandler(async (req, res) => {
  const task = await Task.findOne({ _id: req.params.id, user: req.user.id });
  if (!task) throw new AppError("Task not found", 404);
  res.json({ success: true, task });
});

exports.updateTask = asyncHandler(async (req, res) => {
  const updates = {};
  const allowed = ["title", "description", "status", "dueDate"];
  for (const key of allowed) {
    if (key in req.body) updates[key] = req.body[key];
  }
  if ("dueDate" in updates) {
    updates.dueDate = updates.dueDate ? new Date(updates.dueDate) : null;
  }

  const task = await Task.findOneAndUpdate(
    { _id: req.params.id, user: req.user.id },
    { $set: updates },
    { new: true, runValidators: true }
  );

  if (!task) throw new AppError("Task not found", 404);
  res.json({ success: true, task });
});

exports.deleteTask = asyncHandler(async (req, res) => {
  const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user.id });
  if (!task) throw new AppError("Task not found", 404);
  res.json({ success: true, message: "Task deleted" });
});
