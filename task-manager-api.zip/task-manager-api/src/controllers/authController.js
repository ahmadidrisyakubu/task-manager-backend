const jwt = require("jsonwebtoken");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const User = require("../models/User");

function signToken(userId) {
  const secret = process.env.JWT_SECRET;
  const expiresIn = process.env.JWT_EXPIRES_IN || "7d";
  return jwt.sign({ sub: userId }, secret, { expiresIn });
}

exports.register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;

  const existing = await User.findOne({ email });
  if (existing) throw new AppError("Email already registered", 409);

  const user = await User.create({ name, email, password });
  const token = signToken(user._id.toString());

  res.status(201).json({
    success: true,
    message: "Registration successful",
    token,
    user: { id: user._id, name: user.name, email: user.email },
  });
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email }).select("+password");
  if (!user) throw new AppError("Invalid email or password", 401);

  const ok = await user.comparePassword(password);
  if (!ok) throw new AppError("Invalid email or password", 401);

  const token = signToken(user._id.toString());
  res.json({
    success: true,
    message: "Login successful",
    token,
    user: { id: user._id, name: user.name, email: user.email },
  });
});
