const AppError = require("../utils/AppError");

function notFound(req, res, next) {
  next(new AppError(`Not found: ${req.originalUrl}`, 404));
}

function errorHandler(err, req, res, next) { // eslint-disable-line
  const statusCode = err.statusCode || 500;

  // express-validator / custom meta
  if (err instanceof AppError && err.meta) {
    return res.status(statusCode).json({
      success: false,
      message: err.message,
      ...err.meta,
    });
  }

  // Mongoose duplicate key
  if (err.code === 11000) {
    return res.status(409).json({
      success: false,
      message: "Duplicate value. This email might already be registered.",
    });
  }

  // Mongoose validation
  if (err.name === "ValidationError") {
    const details = Object.values(err.errors).map((e) => e.message);
    return res.status(400).json({
      success: false,
      message: "Validation error",
      details,
    });
  }

  res.status(statusCode).json({
    success: false,
    message: err.message || "Server error",
    ...(process.env.NODE_ENV === "development" ? { stack: err.stack } : {}),
  });
}

module.exports = { notFound, errorHandler };
