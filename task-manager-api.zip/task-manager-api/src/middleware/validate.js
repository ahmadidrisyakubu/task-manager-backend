const { validationResult } = require("express-validator");
const AppError = require("../utils/AppError");

module.exports = (validations) => async (req, res, next) => {
  await Promise.all(validations.map((v) => v.run(req)));
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const details = errors.array().map((e) => ({ field: e.path, message: e.msg }));
    return next(new AppError("Invalid input", 400, { details }));
  }
  next();
};
