const jwt = require("jsonwebtoken");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const User = require("../models/User");

module.exports = asyncHandler(async (req, res, next) => {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.split(" ")[1] : null;

  if (!token) {
    throw new AppError("Unauthorized: Missing token", 401);
  }

  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    throw new AppError("Unauthorized: Invalid or expired token", 401);
  }

  const user = await User.findById(decoded.sub);
  if (!user) throw new AppError("Unauthorized: User not found", 401);

  req.user = { id: user._id, email: user.email, name: user.name };
  next();
});
