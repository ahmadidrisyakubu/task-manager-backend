const { body, param, query } = require("express-validator");

const createTaskValidator = [
  body("title")
    .trim()
    .isLength({ min: 2, max: 120 })
    .withMessage("Title must be between 2 and 120 characters"),
  body("description")
    .optional()
    .isString()
    .isLength({ max: 2000 })
    .withMessage("Description is too long"),
  body("status")
    .optional()
    .isIn(["pending", "done"])
    .withMessage("Status must be 'pending' or 'done'"),
  body("dueDate")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage("dueDate must be a valid date (YYYY-MM-DD or ISO format)"),
];

const updateTaskValidator = [
  param("id").isMongoId().withMessage("Invalid task id"),
  body("title")
    .optional()
    .trim()
    .isLength({ min: 2, max: 120 })
    .withMessage("Title must be between 2 and 120 characters"),
  body("description")
    .optional()
    .isString()
    .isLength({ max: 2000 })
    .withMessage("Description is too long"),
  body("status")
    .optional()
    .isIn(["pending", "done"])
    .withMessage("Status must be 'pending' or 'done'"),
  body("dueDate")
    .optional({ nullable: true })
    .isISO8601()
    .withMessage("dueDate must be a valid date (YYYY-MM-DD or ISO format)"),
];

const taskIdValidator = [param("id").isMongoId().withMessage("Invalid task id")];

const listTasksValidator = [
  query("page").optional().isInt({ min: 1 }).withMessage("page must be >= 1"),
  query("limit").optional().isInt({ min: 1, max: 100 }).withMessage("limit must be 1-100"),
  query("status").optional().isIn(["pending", "done"]).withMessage("status must be pending|done"),
];

module.exports = {
  createTaskValidator,
  updateTaskValidator,
  taskIdValidator,
  listTasksValidator,
};
